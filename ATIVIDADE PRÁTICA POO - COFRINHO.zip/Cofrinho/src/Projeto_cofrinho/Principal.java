package Projeto_cofrinho;

import java.util.ArrayList;
import java.util.List;

public class Principal {

	public static void main(String[] args) {
		
	Menu menu = new Menu();
	menu.exibirMenuPrincipal();
		
		
	
	}	

}
