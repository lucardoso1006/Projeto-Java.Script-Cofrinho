package Projeto_cofrinho;

import java.util.Scanner;

public class Menu {
	
	private Scanner sc;
	private Cofrinho cofrinho;
	
	public Menu() {
		sc = new Scanner(System.in);
		cofrinho = new Cofrinho();
	}

	public void exibirMenuPrincipal() {
		System.out.println("Cofrinho");
		System.out.println("1 - Adicionar moeda");
		System.out.println("2 - Remover moeda");
		System.out.println("3 - Listar moedas");
		System.out.println("4 - Converter valor total para moeda 'Real' ");
		System.out.println("0 - Encerrar");
		
		String opcaoSelecionada = sc.next();
		
		switch	(opcaoSelecionada)	{
		
		case "0":
			System.out.println("Pedido finalizado!");
			break;
			
		case"1":
			exibirSubMenuAdicionarMoedas();
			exibirMenuPrincipal();
			break;
			
		case "2":
			exibirSubMenuRemoverMoedas();
			exibirMenuPrincipal();
			break;
			
		case "3":
			cofrinho.listagemMoedas();
			exibirMenuPrincipal();
			break;
			
		case "4":
			double valorTotalConvertido = cofrinho.totalConvertido();
			String valorTotalConvertidoTextual = String.valueOf(valorTotalConvertido);
			valorTotalConvertidoTextual = valorTotalConvertidoTextual.replace(".", ",");  // essa string altera o ponto pela virgula
			System.out.println("O valor total convertido para real: " + valorTotalConvertido);
			exibirMenuPrincipal();
			break;
			
		default:
			System.out.println("Opção inválida!");
			exibirMenuPrincipal();
			break;
		}
	}
	
	
	private void exibirSubMenuAdicionarMoedas() {
		System.out.println("Escolha uma moeda:");
		System.out.println("1 - Real");
		System.out.println("2 - Dolar");
		System.out.println("3 - Euro");
	
		int opcaoMoeda = sc.nextInt();
	
		System.out.println("Digite o valor:");
	
		String valorTextualMoeda = sc.next();
		valorTextualMoeda = valorTextualMoeda.replace(",", ".");  // essa string altera a virgula pelo ponto
			double valorMoeda = Double.valueOf(valorTextualMoeda);
	
			Moeda moeda = null;
	
			if (opcaoMoeda == 1) {
				moeda = new Real(valorMoeda);
			} else if(opcaoMoeda == 2) {				
				moeda = new Dolar(valorMoeda);
			} else if(opcaoMoeda == 3) {
				moeda = new Euro(valorMoeda);
			} else {
				System.out.println("Opção inválida!");
				exibirMenuPrincipal();
	}
	
			cofrinho.adicionar(moeda);
			System.out.println("Moeda adicionada com sucesso!");

	}
	
	private void exibirSubMenuRemoverMoedas() {
		System.out.println("Escolha uma moeda para remover:");
		System.out.println("1 - Real");
		System.out.println("2 - Dolar");
		System.out.println("3 - Euro");
	
		int opcaoMoeda = sc.nextInt();
	
		System.out.println("Digite o valor:");
	
		String valorTextualMoeda = sc.next();
		valorTextualMoeda = valorTextualMoeda.replace(",", ".");  
		double valorMoeda = Double.valueOf(valorTextualMoeda);
	
		Moeda moeda = null;
	
		if (opcaoMoeda == 1) {
			moeda = new Real(valorMoeda);
		} else if (opcaoMoeda == 2) {				
			moeda = new Dolar(valorMoeda);
		} else if (opcaoMoeda == 3) {
			moeda = new Euro(valorMoeda);
		} else {
			System.out.println("Opção inválida!");
			exibirMenuPrincipal();
		}
	
		
		cofrinho.remover(moeda);
		
	}

}

