/**
 * 
 */
/**
 * 
 */
module Cofrinho {
}